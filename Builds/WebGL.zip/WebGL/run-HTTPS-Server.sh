if [ ! -d "$HOME/.localhost-ssl" ]
then
  mkdir ~/.localhost-ssl
fi

sudo openssl genrsa -out ~/.localhost-ssl/localhost.key 2048

sudo openssl req -new -x509 -key ~/.localhost-ssl/localhost.key -out ~/.localhost-ssl/localhost.crt -days 3650 -subj /CN=localhost

sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain ~/.localhost-ssl/localhost.crt

npm install -g http-server

http-server --ssl --cert ~/.localhost-ssl/localhost.crt --key ~/.localhost-ssl/localhost.key